# Cloak Of Darkness Sample Game

from PAWS.Core import *      # Game Engine (already written for you)
from PAWS.Universe import *  # Game World Library (already written for you)

#------------------ Game data (filled out for each new game) --------------------

Game.Author = "Roger Firth (implemented by Neil Cerutti)"
Game.Copyright = "1999-2000"
Game.Name = "Cloak of Darkness"
Game.Version = "1.5"
Game.IntroText = """
                 Hurrying through the rainswept November night, you're glad
                 to see the bright lights of the Opera House. It's 
                 surprising that there aren't more people about, but, hey,
                 what do you expect from a cheap demo game? 
                 \u0e2e
                 """
#-------------------------------- Game Setup ---------------------------------------

# Copied from game to game, just replace "Cloak" with your game's name and
# replace "Foyer" with your game's starting room.

def CloakUserSetUpGame():
    Global.Production = FALSE
    P.AP().CurrentActor = Global.Player
    P.CA().StartingLocation = Foyer

# Wrapup is always written by you, and optional. This is the final chance to
# print text to the screen just before the game ends.

def CloakPostGameWrapUp():
    if not Bar.Visited: return
    if Sawdust.Trampled < 2:
        Say("~p *** You have won. *** ~p ")
    else:
        Say("~p *** You have lost. *** ~p ")

# Hook up your functions to the game engine. Replace "Cloak" with your game name.

Engine.UserSetUpGame = CloakUserSetUpGame   # Always copy this line
Engine.PostGameWrapUp = CloakPostGameWrapUp # Delete this if no game wrapup

#------------------------------ Room "Blueprints" -------------------------------

# Using blueprints will make more sense when you write bigger games, with one
# blueprint making dozens of different rooms, speeding development considerably.

class MakeCODRoom(ServiceDictDescription, ClassRoom):
    """Blueprint for all rooms in game."""
    def SetMyProperties(self):
        self.IsLit = TRUE
  
    def FeelDesc(self):
        return ClassRoom.FeelDesc(self)

class MakeBar(MakeCODRoom):
    """Blueprint for bar, based on a regular COD room."""
    def SetIsLit(self, LightStatus):
        """Change lighting in bar."""
        self.IsLit = LightStatus
        return ""

class MakeNowhere(MakeCODRoom):
    """Blueprint for Nowhere room, based on regular COD room."""
    def Enter(self, Object):
        if Bar.IsLit:
            return Complain("There's no exit in that direction.")
        else:
            Sawdust.Trampled += 1
            return Complain("Blundering around in the dark isn't a good idea.")
        
#---------------------------- Thing "Blueprints" --------------------------------

# Things, like rooms, need blueprints. In bigger games you can use the same 
# blueprint to make many different things, saving you a LOT of effort.

class MakeCloak(ClassItem):
    """Blueprint for cloak."""
    def Drop(self, Multiple=FALSE):
        """You can't put the cloak anywhere but on the hook."""
        return Complain("This isn't the best place to leave a smart cloak lying around.")

class MakeHook(ServiceActivation, ClassShelf):
    """Blueprint for hook."""
    def Enter(self, Object):
        """Turn on the light in the Bar when player puts the cloak on the hook."""
        if Object == Cloak: Bar.SetIsLit(TRUE)
        return ClassShelf.Enter(self, Object)

class MakeSawdust(ClassScenery):
    """Blueprint for sawdust."""
    def SetMyProperties(self):
        self.Trampled = 0

    def ReadDesc(self):
        Global.GameState = FINISHED
        if self.Trampled < 2:
            return "The message, neatly marked in the sawdust, reads..."
        else:
            return """
                   The message has been carelessly trampled, making it
                   difficult to read. You can just distinguish the words...
                   """
#---------------------------------- Make Rooms ----------------------------------

Foyer = MakeCODRoom()
Foyer.NamePhrase = "Foyer of the Opera House"
Foyer.SetDesc("L","""
                  You are standing in a spacious hall, splendidly decorated
                  in red and gold, with glittering chandeliers overhead. The
                  entrance from the street is to the north, and there are
                  doorways south and west.
                  """)

Cloakroom = MakeCODRoom()
Cloakroom.NamePhrase = "Cloakroom"
Cloakroom.SetDesc("L","""
                      The walls of this small room were clearly once lined
                      with hooks, though now only one remains. The exit is a
                      door to the east.
                      """)

Bar = MakeBar()
Bar.NamePhrase = "Foyer Bar"
Bar.IsLit = FALSE
Bar.SetDesc("Floor","{Sawdust.ReadDesc()}")
Bar.SetDesc("L","""
                The bar, much rougher than you expected after the opulence of the
                northern foyer, is completely empty. There seems to be some sort
                of message scrawled in the sawdust on the floor.
                """)

Nowhere = MakeNowhere()
Nowhere.NamePhrase = "Nowhere Room"

#---------------------------------- Make Things ---------------------------------

Cloak = MakeCloak("cloak","velvet,black,satin,dark,handsome")
Cloak.StartingLocation = Global.Player
Cloak.Bulk = 1
Cloak.Weight = 10
Cloak.SetDesc("Take", "{Bar.SetIsLit(FALSE)}Taken.")
Cloak.SetDesc("L", """
                   A handsome cloak, of velvet trimmed with satin, and
                   slightly spattered with raindrops. Its blackness is so
                   deep that it almost seems to suck light from the room.
                   """)

Hook = MakeHook("hook,peg","small,brass")
Hook.MaxBulk = 1
Hook.MaxWeight = 10
Hook.StartingLocation = Cloakroom
Hook.ActivateSpontaneousPhrase = "I don't know how to do that."
Hook.ActivatePassivePhrase = "I don't know how to do that."
Hook.SetDesc("Take", "The hook is screwed to the wall.")
Hook.SetDesc("L", """
                  It's just a small brass hook,
                  {Choose (Cloak in Self().Contents,
                           " with a cloak hanging on it.",
                           " screwed to the wall.")}
                  """)

Sawdust = MakeSawdust("message,sawdust,floor")
Sawdust.SetDesc("L", "{Self().ReadDesc()}")
Sawdust.ParserFavors = TRUE
Sawdust.StartingLocation = Bar

#--------------------------- Maps (Always Defined Last!) ------------------------

Foyer.Map = {North: """
                    You've only just arrived and besides, the weather
                    outside seems to be getting worse.
                    """,
             South: Bar,
             West:  Cloakroom}

Cloakroom.Map = {East: Foyer}

Bar.Map = {North:      Foyer,
           Northeast:  Nowhere,
           East:       Nowhere,
           Southeast:  Nowhere,
           South:      Nowhere,
           Southwest:  Nowhere,
           West:       Nowhere,
           Northwest:  Nowhere,
           Up:         Nowhere,
           Down:       Nowhere,
           Upstream:   Nowhere,
           Downstream: Nowhere,
           In:         Nowhere,
           Out:        Nowhere}